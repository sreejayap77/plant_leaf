from data_preprocessor import preprocess_data
from execution_pipeline import execute_func
flag = 0

def drive_code(train_percent, num_rounds):

    if flag:
        # preprocess the data
        preprocess_data()

    # paths of the data
    RAW_DATASET_PATH = r"tomato_raw"
    PREPROCESSED_DIR = r"tomato_preprocessed"

    # the training data percentage
    trp = train_percent/100


    # IOT Simulation and Proposed method:
    Accuracy, Sensitivity, Specificity, Precision,\
    F1_Score, Balanced_Accuracy, Energy_J, Delay_s = execute_func(
        dataset_directory=RAW_DATASET_PATH,
        preprocessed_directory=PREPROCESSED_DIR,
        train_percent=trp, num_rounds=num_rounds)

    return Accuracy, Sensitivity, Specificity, Precision, F1_Score, Balanced_Accuracy, Energy_J, Delay_s

