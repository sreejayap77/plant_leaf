import numpy as np

from typing import Callable, List, Tuple, Optional, Dict



class SEwWSAOptimizer:
    """
    Serial Exponential Weighted Wave Search Algorithm (SEWWSA).
    Integrates WSA radar mechanisms with SEWSA routing equations.
    """

    def __init__(self, num_particles: int, dim: int, max_iter: int, lb: float, ub: float):
        self.n = num_particles
        self.d = dim
        self.T = max_iter
        self.lb = lb
        self.ub = ub

        # Eq (1): Initialize position matrix W
        self.W = np.zeros((self.n, self.d))

        # Eq (2): Initialize fitness vector F
        self.F = np.zeros(self.n)

        # Historical state matrices for SEWSA (t, t-1, t-2, t-3)
        self.x_history = [np.zeros((self.n, self.d)) for _ in range(4)]
        self.xE_history = [np.zeros((self.n, self.d)) for _ in range(4)]

        self.W_best = np.zeros(self.d)
        self.f_best = float('inf')  # Assuming minimization for fitness

    def _initialize_population(self):
        """
        Initializes the population using homogenized random numbers.
        """
        # Eq (3): Prepare random numbers k_i and homogenized x_i
        k = np.random.rand(self.n, self.d)
        sum_k = np.sum(k, axis=0)
        x_star = np.cumsum(k, axis=0) / sum_k

        # Eq (4): Initialize particle positions W = lb + x* (ub - lb)
        self.W = self.lb + x_star * (self.ub - self.lb)

        for i in range(4):
            self.x_history[i] = np.copy(self.W)
            self.xE_history[i] = np.copy(self.W)

    def routing_fitness(self, ec: np.ndarray, distance: np.ndarray, delay: np.ndarray, nf: float) -> np.ndarray:
        """
        4.1.2 Fitness Evaluation
        Flt(mis) = ((EC + D + d) / 3) * (1 / Nf).
        """
        flt_mis = ((ec + distance + delay) / 3.0) * (1.0 / nf)
        return flt_mis

    def _calculate_gradient(self, obj_func: Callable, W_i: np.ndarray, epsilon: float = 1e-6) -> np.ndarray:
        """
        Eq (9): Reflect electromagnetic waves using central difference gradient.
        g_i = (f(W_{+ei}) - f(W_{-ei})) / 2e
        """
        g_i = np.zeros(self.d)
        for j in range(self.d):
            W_plus = np.copy(W_i)
            W_minus = np.copy(W_i)
            W_plus[j] += epsilon
            W_minus[j] -= epsilon

            g_i[j] = (obj_func(W_plus) - obj_func(W_minus)) / (2 * epsilon)
        return g_i

    def _boundary_handling(self, W_i: np.ndarray) -> np.ndarray:
        """
        Eq (13): Generalized boundary restriction rule.
        W_i = lb + r * (ub - lb) if W_i > ub or W_i < lb
        """
        out_of_bounds = (W_i > self.ub) | (W_i < self.lb)
        if np.any(out_of_bounds):
            r = np.random.rand(self.d)
            W_i[out_of_bounds] = self.lb + r[out_of_bounds] * (self.ub - self.lb)
        return W_i

    def optimize(
        self,
        obj_func: Callable,
        track_diagnostics: bool = False,
    ):
        """
        Main optimization loop executing WSA steps fused with SEWSA.

        By default returns (W_best, f_best) -- same 2-tuple as before, so
        existing callers that unpack `best_pos, best_fit = opt.optimize(...)`
        keep working unchanged.

        If track_diagnostics=True, returns a 3-tuple (W_best, f_best, diagnostics)
        instead, where diagnostics is a dict with per-iteration 'f_best', 'f_mean',
        and 'diversity' (population std) traces -- useful for plotting/checking
        whether the population is losing diversity and stalling before max_iter
        is reached.
        """
        self._initialize_population()

        diagnostics: Optional[Dict[str, list]] = (
            {"f_best": [], "f_mean": [], "diversity": []} if track_diagnostics else None
        )

        # Calculate initial fitness
        for i in range(self.n):
            self.F[i] = obj_func(self.W[i])
            if self.F[i] < self.f_best:
                self.f_best = self.F[i]
                self.W_best = np.copy(self.W[i])

        alpha = 0.45  # Step coefficient initial value
        sewsa_alpha = 0.5  # EWMA alpha weight

        # Array to store W_best for convolution in Eq (11)
        historical_W_best = []

        # Wrapped range with tqdm to track progress
        for t in range(1, self.T + 1):
            f_mean = np.mean(self.F)
            f_max = np.max(self.F)

            W_min = np.min(self.W, axis=0)
            W_max = np.max(self.W, axis=0)

            historical_W_best.append(np.copy(self.W_best))

            for i in range(self.n):
                # ---------------------------------------------------------
                # 1. Global Exploration
                # ---------------------------------------------------------
                r1 = np.random.rand()
                # Eq (5): W_i^new = W_min + r1 * (W_max - W_min)
                W_new = W_min + r1 * (W_max - W_min)
                W_new = self._boundary_handling(W_new)

                f_new = obj_func(W_new)
                # Eq (6): Greedy mechanism based on f_mean
                if f_new <= f_mean:
                    self.W[i] = W_new
                    self.F[i] = f_new

            # ---------------------------------------------------------
            # 2. Local Exploitation (SEWWSA OVERRIDE)
            # ---------------------------------------------------------
            if t > 0.2 * self.T:
                ratio = (5.0 * t) / self.T
                numerator = -(ratio - 2.0)
                denominator = np.sqrt(25.0 * (ratio - 2.0) ** 2) + 1e-8
                sigma = (numerator / denominator) + 0.4

                m = np.random.randn(self.n)

                for i in range(self.n):
                    xE_t = self.xE_history[0][i]
                    x_t1 = self.x_history[1][i]
                    x_t2 = self.x_history[2][i]
                    xE_t3 = self.xE_history[3][i]

                    inner_term = sewsa_alpha * x_t1 + (1 - sewsa_alpha) * (
                                sewsa_alpha * x_t2 + (1 - sewsa_alpha) * xE_t3)
                    x_t_rewritten = (1.0 / sewsa_alpha) * (xE_t - (1 - sewsa_alpha) * inner_term)

                    # 4.1.3 Algorithm Substitute 2 in 1
                    m_i = m[i]
                    exploitation = (x_t_rewritten * (1 + m_i)) + (self.W_best * (sigma - m_i - 1))
                    W_new = (1.0 / sigma) * exploitation

                    W_new = self._boundary_handling(W_new)
                    f_new = obj_func(W_new)

                    # Eq (8): Greedy mechanism based on f_max
                    if f_new <= f_max:
                        self.W[i] = W_new
                        self.F[i] = f_new

                    # ---------------------------------------------------------
                    # 3. Reflect Electromagnetic Waves
                    # ---------------------------------------------------------
                    g_i = self._calculate_gradient(obj_func, self.W[i])

                    # Eq (10): W_i = W_i - alpha * g_i
                    W_reflected = self.W[i] - alpha * g_i
                    W_reflected = self._boundary_handling(W_reflected)

                    f_reflected = obj_func(W_reflected)
                    if f_reflected <= self.F[i]:
                        self.W[i] = W_reflected
                        self.F[i] = f_reflected
                        alpha *= 1.5  # Step length trial success
                    else:
                        alpha *= 0.5  # Step length trial failure

                    # ---------------------------------------------------------
                    # 4. Receive Electromagnetic Waves
                    # ---------------------------------------------------------
                    delta = 0.6 + (1.2 - 0.5) * np.sin((t * np.pi) / (2 * self.T))
                    eta = np.random.randn(self.d)

                    W_best_star = np.mean(historical_W_best, axis=0)

                    lambda_factor = ((2 * t / self.T) - 0.7) / (0.78 + abs((2 * t / self.T) - 0.7)) + 1
                    r2, r3, r4, r5 = np.random.rand(4)

                    # Eq (11): W_i^new piecewise function based on r5
                    if r5 <= 0.7:
                        W_received = self.W[i] + delta * r2 * (self.W_best - self.W[i]) + eta * np.cos(
                            np.pi * i / self.n) * (self.W_best - self.W[i])
                    else:
                        W_received = self.W[i] + lambda_factor * r3 * (self.W_best - self.W[i]) + 0.5 * r4 * (
                                    1 - lambda_factor) * (W_best_star - self.W[i])

                    W_received = self._boundary_handling(W_received)
                    f_received = obj_func(W_received)

                    # Eq (12): Greedy update for received wave
                    if f_received <= self.F[i]:
                        self.W[i] = W_received
                        self.F[i] = f_received

            self.x_history.insert(0, np.copy(self.W))
            self.x_history.pop()

            new_xE = sewsa_alpha * self.W + (1 - sewsa_alpha) * self.xE_history[0]
            self.xE_history.insert(0, new_xE)
            self.xE_history.pop()

            # Update Global Best
            min_idx = np.argmin(self.F)
            if self.F[min_idx] < self.f_best:
                self.f_best = self.F[min_idx]
                self.W_best = np.copy(self.W[min_idx])

            if diagnostics is not None:
                diagnostics["f_best"].append(self.f_best)
                diagnostics["f_mean"].append(float(np.mean(self.F)))
                diagnostics["diversity"].append(float(np.std(self.W)))

        if track_diagnostics:
            return self.W_best, self.f_best, diagnostics
        return self.W_best, self.f_best