import os
import warnings
import colorlog
import logging
import PySimpleGUI as sg
import RUN

# ================= LOGGER SETUP =================
handler = colorlog.StreamHandler()
handler.setFormatter(colorlog.ColoredFormatter(
    "%(log_color)s%(message)s",
    log_colors={
        'DEBUG': 'green',
        'INFO': 'cyan',
        'WARNING': 'yellow',
        'ERROR': 'red',
        'CRITICAL': 'bold_red',
    }
))

logger = colorlog.getLogger()
logger.addHandler(handler)

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
warnings.filterwarnings('ignore')

# ================= GUI THEME & STYLES =================
sg.theme('DarkBlue3')

FONT_TITLE = ('Helvetica', 14, 'bold')
FONT_HEADER = ('Helvetica', 12, 'bold')
FONT_TEXT = ('Helvetica', 12)

# ================= LAYOUT COMPONENTS =================

# 1. Configuration Panel
control_frame = [
    [sg.Text("Training Data Split (%):", font=FONT_HEADER, size=(23, 1)),
     sg.Combo([60, 70, 80, 90],
              size=(28, 1), key='TRAIN', readonly=True, font=FONT_TEXT)],
    [sg.Text("Number of Rounds:", font=FONT_HEADER, size=(23, 1)),
     sg.Combo([500, 1000, 1500, 2000],
              size=(28, 1), key='ROUNDS', readonly=True, font=FONT_TEXT)]
]


# Helper function to generate professional metric display cards
def metric_card(title, key, width=14):
    return sg.Column([
        [sg.Text(title, font=FONT_HEADER, justification='center', expand_x=True)],
        [sg.Input("", key=key, size=(width, 1), font=('Helvetica', 14, 'bold'),
                  justification='center', readonly=True, text_color='#1E90FF')]
    ], element_justification='center', pad=(8, 10))


# 2. Proposed Method Metrics Panel (6 Metrics arranged in a 2x3 grid)
proposed_metrics_frame = [
    [metric_card("Accuracy", "ACC"),
     metric_card("Sensitivity", "SEN"),
     metric_card("Specificity", "SPE")],

    [metric_card("Precision", "PRE"),
     metric_card("F1-Score", "F1"),
     metric_card("Balanced Accuracy", "BACC")]
]

# 3. IOT Simulation Panel (2 Metrics)
iot_metrics_frame = [
    [metric_card("Energy (J)", "ENG", width=20),
     metric_card("Delay (s)", "DLY", width=20)]
]

# 4. Main Window Assembly
layout = [
    [sg.Frame("", control_frame,
              pad=15, border_width=2, font=FONT_TITLE, title_color='white')],

    [sg.Frame(" Proposed SEwWSA Hybrid 1D CNN-PolyNet  ", proposed_metrics_frame,
              pad=15, border_width=2, font=FONT_TITLE, title_color='white')],

    [sg.Frame(" IOT Simulation ", iot_metrics_frame,
              pad=15, border_width=2, font=FONT_TITLE, title_color='white')],

    [sg.Button("START EXECUTION", size=(20, 2), font=('Helvetica', 12, 'bold'),
               button_color=('white', '#2E8B57'), pad=(15, 20)),
     sg.Button("CLOSE", size=(15, 2), font=('Helvetica', 12, 'bold'),
               button_color=('white', '#B22222'), pad=(15, 20))]
]

# ================= WINDOW INITIALIZATION =================
window = sg.Window(
    "Simulation & Performance Analyzer",
    layout,
    element_justification='center',
    size=(700, 660),  # Adjusted size to fit the new combo box
    resizable=False,
    finalize=True
)

# ================= EVENT LOOP =================
while True:
    event, values = window.read()

    if event in (sg.WIN_CLOSED, "CLOSE"):
        break

    if event == "START EXECUTION":

        if not values['TRAIN'] or not values['ROUNDS']:
            sg.popup_error("Configuration Error", "Please select both Training Percentage and Number of Rounds.", font=FONT_TEXT)
            continue

        tr_p = int(values['TRAIN'])
        num_rounds = int(values['ROUNDS'])

        try:
            # ---------------------------------------------------------
            # Ensure your RUN.drive_code() is updated to accept both parameters
            # and returns exactly 8 values in this specific order:
            # ---------------------------------------------------------
            Accuracy, Sensitivity, Specificity, Precision, F1_score, Balanced_Accuracy, Energy, Delay = RUN.drive_code(tr_p, num_rounds)


            # Helper function to extract safely in case RUN.main returns lists instead of single floats
            def extract_metric(metric):
                if isinstance(metric, (list, tuple)):
                    return metric[-1]
                return metric


            # ----------------- Proposed Method Metrics -----------------
            window['ACC'].update(f"{extract_metric(Accuracy):.4f}")
            window['SEN'].update(f"{extract_metric(Sensitivity):.4f}")
            window['SPE'].update(f"{extract_metric(Specificity):.4f}")
            window['PRE'].update(f"{extract_metric(Precision):.4f}")
            window['F1'].update(f"{extract_metric(F1_score):.4f}")
            window['BACC'].update(f"{extract_metric(Balanced_Accuracy):.4f}")

            # ------------------- IOT Simulation Metrics ----------------
            window['ENG'].update(f"{extract_metric(Energy):.6f}")
            window['DLY'].update(f"{extract_metric(Delay):.6f}")

            sg.popup_ok("Success", f"Evaluation completed for Training Split: {tr_p}% and Rounds: {num_rounds}", font=FONT_TEXT)

        except ValueError as ve:
            sg.popup_error("Data Unpacking Error",
                           "Make sure RUN.drive_code(tr_p, num_rounds) returns exactly 8 metrics.\n\n"
                           "Expected: Accuracy, Sensitivity, Specificity, Precision, F1_score, Balanced_Accuracy, Energy, Delay",
                           font=FONT_TEXT)
        except Exception as e:
            sg.popup_error("Execution Error", f"An error occurred during evaluation:\n\n{str(e)}", font=FONT_TEXT)

window.close()
logging.info("\nDone ..")