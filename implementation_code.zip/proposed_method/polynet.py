import os
import csv
import numpy as np
import cv2
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader, random_split
from torchvision import transforms
from sklearn.metrics import confusion_matrix
from tqdm import tqdm
from pretrainedmodels import polynet


# ==========================================
# 1. PolyNet Branch & Hybrid Fusion Model
# ==========================================

class PolyNetBranch(nn.Module):
    """PolyNet feature extraction backbone utilizing the pretrainedmodels package."""

    def __init__(self, feature_dim=128):
        super(PolyNetBranch, self).__init__()

        # Load the pretrained PolyNet model
        self.model = polynet(pretrained=None)

        # Override the final linear layer to output the desired feature dimension
        in_features = self.model.last_linear.in_features
        self.model.last_linear = nn.Linear(in_features, feature_dim)

        # Ensure dynamic compatibility regardless of input image dimensions
        self.model.avg_pool = nn.AdaptiveAvgPool2d((1, 1))

    def forward(self, x):
        return self.model(x)


class HybridFusionModel(nn.Module):
    """Integrates PolyNet features with loaded 1D CNN predictions using Map/Merging layers."""

    def __init__(self, num_classes=10):
        super(HybridFusionModel, self).__init__()
        self.polynet = PolyNetBranch(feature_dim=128)

        self.merging_layer = nn.Sequential(
            nn.Linear(128 + num_classes, 64),
            nn.ReLU(),
            nn.Dropout(0.4),
            nn.Linear(64, num_classes)
        )

    def forward(self, image_tensor, previous_predictions):
        # PolyNet only processes the image
        xa = self.polynet(image_tensor)

        # We concatenate the PolyNet features with the 1D CNN predictions here
        fused_features = torch.cat((xa, previous_predictions), dim=1)

        return self.merging_layer(fused_features)


# ==========================================
# 2. Dataset Wrapper for Raw Image Loading
# ==========================================
class HybridDataset(Dataset):
    """Loads raw images dynamically and uses the extracted_data list from the 1D CNN."""

    def __init__(self, extracted_data, num_classes=10, raw_data_dir=None):
        self.data_records = []
        self.raw_data_dir = raw_data_dir
        self.num_classes = num_classes

        self.transform = transforms.Compose([
            transforms.ToPILImage(),
            transforms.Resize((224, 224)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ])

        # Skip the header row
        for row in extracted_data[1:]:
            img_path = row[0]

            if raw_data_dir and "train_preprocessed" in img_path:
                img_path = img_path.replace("train_preprocessed", "train_raw")

            true_label = int(float(row[1]))
            predicted_class = int(float(row[2]))

            # Convert the single predicted class into a one-hot encoded array of length 10
            pred_one_hot = np.zeros(self.num_classes, dtype=np.float32)
            pred_one_hot[predicted_class] = 1.0

            self.data_records.append((img_path, true_label, pred_one_hot))

    def __len__(self):
        return len(self.data_records)

    def __getitem__(self, idx):
        img_path, label, pred_one_hot = self.data_records[idx]

        img = cv2.imread(img_path)
        if img is None:
            raise ValueError(f"Could not read image at {img_path}")

        img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        tensor_img = self.transform(img_rgb)

        pred_tensor = torch.from_numpy(pred_one_hot)

        return tensor_img, label, pred_tensor, img_path


# ==========================================
# 3. Training & Metric Calculation Function
# ==========================================
def train_and_evaluate_hybrid(
        predicted_data,
        train_percent=0.8,
        num_epochs=5,
        batch_size=5,
        model_path="checkpoints/polynet_hybrid_model.pth",
        raw_data_dir="tomato/train_raw"
):
    dataset = HybridDataset(predicted_data, raw_data_dir=raw_data_dir)

    split_ratio = train_percent if train_percent <= 1.0 else train_percent / 100.0
    train_size = int(split_ratio * len(dataset))
    test_size = len(dataset) - train_size

    train_dataset, test_dataset = random_split(
        dataset,
        [train_size, test_size],
        generator=torch.Generator().manual_seed(42)
    )

    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

    model = HybridFusionModel(num_classes=10)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)

    if os.path.exists(model_path):
        model.load_state_dict(torch.load(model_path, map_location=device))
    else:
        criterion = nn.CrossEntropyLoss()
        optimizer = optim.Adam(model.parameters(), lr=0.001)

        for epoch in range(num_epochs):
            model.train()
            running_loss = 0.0
            pbar = tqdm(train_loader, desc=f"PolyNet Hybrid Training Epoch [{epoch + 1}/{num_epochs}]")

            for inputs, labels, previous_preds, _ in pbar:
                inputs = inputs.to(device)
                labels = labels.to(device)
                previous_preds = previous_preds.to(device)

                optimizer.zero_grad()
                outputs = model(inputs, previous_preds)
                loss = criterion(outputs, labels)
                loss.backward()
                optimizer.step()

                running_loss += loss.item()
                pbar.set_postfix({"Loss": f"{running_loss / (pbar.n + 1):.4f}"})

        torch.save(model.state_dict(), model_path)

    model.eval()
    all_preds = []
    all_labels = []

    # We will return the predictions as a list just like the first model
    hybrid_extracted_data = []
    hybrid_extracted_data.append(["Image_Name", "True_Label", "Predicted_Class"])

    with torch.no_grad():
        pbar_eval = tqdm(test_loader, desc="PolyNet Hybrid Testing")
        for inputs, labels, previous_preds, paths in pbar_eval:
            inputs = inputs.to(device)
            labels = labels.to(device)
            previous_preds = previous_preds.to(device)

            outputs = model(inputs, previous_preds)
            _, predicted = torch.max(outputs, 1)

            preds_cpu = predicted.cpu().numpy()
            labels_cpu = labels.cpu().numpy()

            all_preds.extend(preds_cpu)
            all_labels.extend(labels_cpu)

            for i in range(len(paths)):
                image_name = os.path.basename(paths[i])
                hybrid_extracted_data.append([image_name, labels_cpu[i], preds_cpu[i]])

    return hybrid_extracted_data