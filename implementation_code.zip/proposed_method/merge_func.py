import os
import torch
import pandas as pd
import numpy as np
import cv2
import joblib
from pathlib import Path
from sklearn.linear_model import Ridge
from sklearn.preprocessing import OneHotEncoder
from sklearn.metrics import confusion_matrix
from tqdm import tqdm


def merge_layer(dataset_dir, polynet_preds_data, Accuracy, Sensitivity, Specificity, Precision, F1_score,
                model_save_path="checkpoints/merger_weights.joblib"):
    dataset_path = Path(dataset_dir)

    # --------------------------------
    # 1. RECONSTRUCT GROUND TRUTH MAPPING
    # --------------------------------
    # Sort folders alphabetically to exactly match PyTorch's internal class_to_idx mapping
    class_folders = sorted([d.name for d in dataset_path.iterdir() if d.is_dir()])
    label_map = {c.strip().lower(): i for i, c in enumerate(class_folders)}
    NUM_CLASSES = len(label_map)

    # --------------------------------
    # 2. LOAD POLYNET PREDICTIONS DIRECTLY FROM LIST
    # --------------------------------
    # polynet_preds_data is expected to be a list of lists, where the first element is the header.
    # Format: [["Image_Name", "True_Label", "Predicted_Class"], ["img1.jpg", 0, 0], ...]

    X_2_cleaned = {}
    for row in polynet_preds_data[1:]:  # Skip the header row
        image_name_stem = Path(str(row[0])).stem.strip()
        predicted_class = int(float(row[2]))
        X_2_cleaned[image_name_stem] = predicted_class

    test_names = list(X_2_cleaned.keys())

    # --------------------------------
    # 3. LOAD PREPROCESSED IMAGES
    # --------------------------------
    data = []

    # Convert generator to list to allow tqdm to calculate total progress percentage
    image_files = list(dataset_path.rglob("*.*"))

    for img_file in tqdm(image_files, desc="Loading and processing images"):
        if img_file.suffix.lower() not in ['.jpg', '.jpeg', '.png']:
            continue

        file_id = img_file.stem.strip()
        label_str = img_file.parent.name.strip().lower()

        # If the physical folder name matches a known class, process the image
        if label_str in label_map:
            img = cv2.imread(str(img_file))
            if img is not None:
                img = cv2.resize(img, (224, 224))
                # Data is flattened here
                flattened_features = (img.flatten() / 255.0).astype(np.float32)

                data.append({
                    'image_name': file_id,
                    'features': flattened_features,
                    'label': label_map[label_str]
                })

    df = pd.DataFrame(data)

    if df.empty:
        raise ValueError(
            "No image data was loaded. Ensure your 'dataset_dir' is correct and that the "
            "subfolders contain valid images."
        )

    # --------------------------------
    # 4. SPLIT TRAIN AND TEST
    # --------------------------------
    df_test = df[df['image_name'].isin(test_names)].copy()
    df_train = df[~df['image_name'].isin(test_names)].copy()

    df_test['image_name'] = pd.Categorical(df_test['image_name'], categories=test_names, ordered=True)
    df_test = df_test.sort_values('image_name').reset_index(drop=True)
    df_train = df_train.reset_index(drop=True)

    X_train = np.stack(df_train['features'].values)
    y_train = df_train['label'].to_numpy()

    X_test = np.stack(df_test['features'].values)
    y_test = df_test['label'].to_numpy()

    # --------------------------------
    # 5. ONE-HOT ENCODE LABELS
    # --------------------------------
    encoder = OneHotEncoder(sparse_output=False, categories='auto')
    y_train_oh = encoder.fit_transform(y_train.reshape(-1, 1))

    # --------------------------------
    # 6. LINEAR REGRESSION MODEL (Load or Train)
    # --------------------------------
    if os.path.exists(model_save_path):
        lr_model = joblib.load(model_save_path)
    else:
        # Added copy_X=False to prevent sklearn from duplicating the 5GB array in RAM
        lr_model = Ridge(alpha=0.1, solver='lsqr', copy_X=False, random_state=42)
        lr_model.fit(X_train, y_train_oh)
        joblib.dump(lr_model, model_save_path)

    # Generate predictions on the test set
    p_Weight = lr_model.predict(X_test)

    # --------------------------------
    # 7. CUSTOM MAP LAYER (St+1)
    # --------------------------------
    # lr_model.coef_ shape is (n_targets, n_features) for multi-target regression
    # Taking mean across axis 0 gets the average weight for each feature across all classes
    Weight = lr_model.coef_.mean(axis=0)
    St1 = np.sum(X_test * Weight * 0.1, axis=1)

    # --------------------------------
    # 8. MERGE LAYER (X_3 = S_t+1 + X_2 * We2)
    # --------------------------------
    # Retrieve the numeric prediction array safely mapped to the test indices
    X2 = np.array([X_2_cleaned[name] for name in df_test['image_name']])

    X_3 = []
    for i in tqdm(range(len(X_test)), desc="Calculating merged features"):
        merged_vector = []
        for c in range(NUM_CLASSES):
            val = St1[i] + (X2[i] * p_Weight[i][c])
            merged_vector.append(val)
        X_3.append(merged_vector)

    X_3 = np.array(X_3)

    # --------------------------------
    # 9. FINAL DECISION
    # --------------------------------
    y_pred = np.argmax(X_3, axis=1)

    # --------------------------------
    # 10. METRICS
    # --------------------------------
    cm = confusion_matrix(y_test, y_pred, labels=np.arange(NUM_CLASSES))

    acc_list, sen_list, spe_list, pre_list, f1_list = [], [], [], [], []

    for c in range(NUM_CLASSES):
        tp = cm[c, c]
        fn = np.sum(cm[c, :]) - tp
        fp = np.sum(cm[:, c]) - tp
        tn = np.sum(cm) - (tp + fp + fn)

        acc_list.append((tp + tn) / (tp + tn + fp + fn + 1e-8))
        sen_list.append(tp / (tp + fn + 1e-8))
        spe_list.append(tn / (tn + fp + 1e-8))
        pre_list.append(tp / (tp + fp + 1e-8))
        f1_list.append((2 * tp) / (2 * tp + fp + fn + 1e-8))

    Accuracy.append(np.mean(acc_list))
    Sensitivity.append(np.mean(sen_list))
    Specificity.append(np.mean(spe_list))
    Precision.append(np.mean(pre_list))
    F1_score.append(np.mean(f1_list))