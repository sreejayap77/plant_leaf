import os
import cv2
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader, random_split
from torchvision import transforms
import numpy as np
from sklearn.metrics import confusion_matrix
from tqdm import tqdm


# ==========================================
# 1. 1D CNN Architecture
# ==========================================
class DiseaseDetector1DCNN(nn.Module):
    """
    1D CNN architecture matched exactly to the provided Keras summary.
    Includes sequential Conv1D blocks, Max Pooling, Batch Normalization, and Dense layers.
    """

    def __init__(self, num_classes=10):
        super(DiseaseDetector1DCNN, self).__init__()

        # Feature Extractor
        self.features = nn.Sequential(
            # Block 1
            nn.Conv1d(in_channels=672, out_channels=64, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool1d(kernel_size=2, stride=2),

            # Block 2
            nn.Conv1d(in_channels=64, out_channels=128, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool1d(kernel_size=2, stride=2),

            # Block 3
            nn.Conv1d(in_channels=128, out_channels=256, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.Conv1d(in_channels=256, out_channels=256, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool1d(kernel_size=2, stride=2),

            # Block 4
            nn.Conv1d(in_channels=256, out_channels=512, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.Conv1d(in_channels=512, out_channels=512, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool1d(kernel_size=2, stride=2),

            # Batch Normalization
            nn.BatchNorm1d(512)
        )

        # Classifier
        self.classifier = nn.Sequential(
            # Flatten layer resolves to 14 * 512 = 7168
            nn.Linear(7168, 1024),
            nn.ReLU(),
            nn.Linear(1024, num_classes)
        )

    def forward(self, x):
        b, c, h, w = x.size()  # PyTorch default: (B, 3, 224, 224)

        # 1. Permute to match Keras shape (B, H, W, C) -> (B, 224, 224, 3)
        x = x.permute(0, 2, 3, 1).contiguous()
        # 2. Reshape to mimic Keras Reshape layer (B, 224, 672)
        x = x.view(b, h, w * c)
        # 3. Transpose for PyTorch Conv1d which expects (Batch, Channels, Sequence_Length)
        x = x.transpose(1, 2)

        # Pass through Conv1D feature blocks
        x = self.features(x)

        # Flatten and pass to dense layers
        x = x.view(b, -1)  # Flattens to (B, 7168)
        x = self.classifier(x)

        return x


# ==========================================
# 2. Dataset Wrapper
# ==========================================
class TomatoLeafDataset(Dataset):
    """Loads already preprocessed images and applies PyTorch tensor conversions."""

    def __init__(self, image_paths):
        self.image_paths = image_paths
        self.classes = sorted(list(set([os.path.basename(os.path.dirname(p)) for p in image_paths])))
        self.class_to_idx = {c: i for i, c in enumerate(self.classes)}

        # [FIX APPLIED HERE]: Added ToPILImage and Resize to strictly enforce 224x224 dimensions
        self.transform = transforms.Compose([
            transforms.ToPILImage(),
            transforms.Resize((224, 224)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ])

    def __len__(self):
        return len(self.image_paths)

    def __getitem__(self, idx):
        img_path = self.image_paths[idx]
        label_str = os.path.basename(os.path.dirname(img_path))
        label = self.class_to_idx[label_str]

        # Read the image
        img = cv2.imread(img_path)
        if img is None:
            raise ValueError(f"Could not read image at {img_path}")

        # Convert BGR to RGB for standard PyTorch image processing
        img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

        # Apply the transform pipeline (which now handles resizing to 224x224)
        tensor_img = self.transform(img_rgb)

        return tensor_img, label, img_path


# ==========================================
# 3. Training & Inference Extraction Function
# ==========================================
def train_and_save_1dcnn(
        model,
        dataset,
        train_percent=0.8,
        num_epochs=2,
        batch_size=32,
        model_path="checkpoints/cnn_1d_model.pth"
):
    """
    Loads the saved 1D CNN model if it exists.
    Otherwise, trains the model and saves it.

    After loading/training:
    - Evaluates the model on the test set.
    - Extracts predictions for the complete dataset.
    - Returns the model and the prediction data (as a list of rows).
    """

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)

    # =========================================================
    # 1. TRAIN OR LOAD MODEL
    # =========================================================

    if os.path.exists(model_path):
        model.load_state_dict(torch.load(model_path, map_location=device))

    else:
        split_ratio = train_percent if train_percent <= 1.0 else train_percent / 100.0
        train_size = int(split_ratio * len(dataset))
        test_size = len(dataset) - train_size

        train_dataset, test_dataset = random_split(
            dataset,
            [train_size, test_size],
            generator=torch.Generator().manual_seed(42)
        )

        train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
        test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

        criterion = nn.CrossEntropyLoss()
        optimizer = optim.Adam(model.parameters(), lr=0.001)

        for epoch in range(num_epochs):
            model.train()
            running_loss = 0.0

            pbar = tqdm(train_loader, desc=f"1D CNN Training Epoch [{epoch + 1}/{num_epochs}]")
            for inputs, labels, _ in pbar:
                inputs = inputs.to(device)
                labels = labels.to(device)

                optimizer.zero_grad()
                outputs = model(inputs)
                loss = criterion(outputs, labels)
                loss.backward()
                optimizer.step()

                running_loss += loss.item()
                pbar.set_postfix({"Loss": f"{running_loss / (pbar.n + 1):.4f}"})

        torch.save(model.state_dict(), model_path)

    # =========================================================
    # 2. CREATE SAME TEST SPLIT FOR EVALUATION
    # =========================================================
    split_ratio = train_percent if train_percent <= 1.0 else train_percent / 100.0
    train_size = int(split_ratio * len(dataset))
    test_size = len(dataset) - train_size

    _, test_dataset = random_split(
        dataset,
        [train_size, test_size],
        generator=torch.Generator().manual_seed(42)
    )

    test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

    # =========================================================
    # 3. EVALUATE MODEL
    # =========================================================
    model.eval()

    all_preds = []
    all_labels = []

    with torch.no_grad():
        pbar_eval = tqdm(test_loader, desc="1D CNN Testing")
        for inputs, labels, _ in pbar_eval:
            inputs = inputs.to(device)
            labels = labels.to(device)

            outputs = model(inputs)
            _, predicted = torch.max(outputs, 1)

            all_preds.extend(predicted.cpu().numpy())
            all_labels.extend(labels.cpu().numpy())

    # =========================================================
    # 4. CALCULATE METRICS
    # =========================================================
    cm = confusion_matrix(all_labels, all_preds)

    FP = cm.sum(axis=0) - np.diag(cm)
    FN = cm.sum(axis=1) - np.diag(cm)
    TP = np.diag(cm)
    TN = cm.sum() - (FP + FN + TP)

    accuracy = np.mean((TP + TN) / (TP + FP + FN + TN + 1e-8))
    sensitivity = np.mean(TP / (TP + FN + 1e-8))
    specificity = np.mean(TN / (TN + FP + 1e-8))

    # =========================================================
    # 5. EXTRACT WHOLE DATASET PREDICTIONS
    # =========================================================
    full_loader = DataLoader(dataset, batch_size=batch_size, shuffle=False)

    predicted_data = []
    header = ["Image_Name", "True_Label", "Predicted_Class"]
    predicted_data.append(header)

    with torch.no_grad():
        pbar_extract = tqdm(full_loader, desc="1D CNN Prediction Extraction")
        for inputs, labels, paths in pbar_extract:
            inputs = inputs.to(device)
            logits = model(inputs)
            _, preds = torch.max(logits, 1)

            preds_cpu = preds.cpu().numpy()
            labels_cpu = labels.numpy()

            for i in range(len(paths)):
                row = [paths[i], labels_cpu[i], preds_cpu[i]]
                predicted_data.append(row)

    return predicted_data