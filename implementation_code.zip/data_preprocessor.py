import os
import cv2
import glob
import shutil
import uuid
from tqdm import tqdm


# ==========================================
# 1. Preprocessor Definition
# ==========================================
class Preprocessor:
    """Handles Image Resizing and Contrast Enhancement (CLAHE) for offline saving."""

    def __init__(self, target_size=(224, 224), clip_limit=2.0, tile_grid_size=(8, 8)):
        self.target_size = target_size
        self.clahe = cv2.createCLAHE(clipLimit=clip_limit, tileGridSize=tile_grid_size)

    def process_and_save(self, input_path: str, output_path: str):
        img = cv2.imread(input_path)
        if img is None:
            return False

        # Apply CLAHE in LAB color space
        lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)
        l, a, b = cv2.split(lab)
        cl = self.clahe.apply(l)
        limg = cv2.merge((cl, a, b))

        # Convert back to BGR for saving with cv2.imwrite
        enhanced_img_bgr = cv2.cvtColor(limg, cv2.COLOR_LAB2BGR)
        resized_img = cv2.resize(enhanced_img_bgr, self.target_size)

        cv2.imwrite(output_path, resized_img)
        return True


# ==========================================
# Step 1: Merge Existing Splits
# ==========================================
def merge_datasets(input_root: str, merged_dir: str):
    """Merges train/val/test folders into a single root folder with class subdirectories."""
    splits = ['train', 'val', 'test']

    # Gather all file paths first to give tqdm an accurate total count
    copy_tasks = []

    for split in splits:
        split_dir = os.path.join(input_root, split)
        if not os.path.exists(split_dir):
            continue

        # Look at the structure matching screen_1.png
        for class_name in os.listdir(split_dir):
            class_path = os.path.join(split_dir, class_name)
            if not os.path.isdir(class_path):
                continue

            target_class_dir = os.path.join(merged_dir, class_name)
            os.makedirs(target_class_dir, exist_ok=True)

            images = glob.glob(os.path.join(class_path, "*.*"))
            for img_path in images:
                # Generate a unique prefix to prevent overwrite if train/val have identical filenames
                file_name = os.path.basename(img_path)
                unique_name = f"{split}_{uuid.uuid4().hex[:8]}_{file_name}"
                target_img_path = os.path.join(target_class_dir, unique_name)

                copy_tasks.append((img_path, target_img_path))

    # Execute copy with a progress bar
    for img_path, target_img_path in tqdm(copy_tasks, desc="Merging Datasets"):
        shutil.copy2(img_path, target_img_path)


# ==========================================
# Step 2: Preprocess the Merged Dataset
# ==========================================
def preprocess_merged_dataset(merged_dir: str, preprocessed_dir: str):
    """Processes every image in the merged directory and saves to a new preprocessed directory."""
    preprocessor = Preprocessor()

    search_pattern = os.path.join(merged_dir, "*", "*.*")
    image_paths = glob.glob(search_pattern)

    if not image_paths:
        return

    # Execute preprocessing with a progress bar
    for img_path in tqdm(image_paths, desc="Preprocessing Images"):
        # Calculate relative path to maintain the exact class sub-folder structure
        rel_path = os.path.relpath(img_path, merged_dir)
        out_path = os.path.join(preprocessed_dir, rel_path)

        os.makedirs(os.path.dirname(out_path), exist_ok=True)
        preprocessor.process_and_save(img_path, out_path)


# ==========================================
# Main Execution Block
# ==========================================
def preprocess_data():
    # Define directories matching the required workflow
    ORIGINAL_DATASET_DIR = "tomato"
    MERGED_DATASET_DIR = "tomato_raw"
    PREPROCESSED_DATASET_DIR = "tomato_preprocessed"

    # Run the pipeline sequentially
    merge_datasets(ORIGINAL_DATASET_DIR, MERGED_DATASET_DIR)
    preprocess_merged_dataset(MERGED_DATASET_DIR, PREPROCESSED_DATASET_DIR)