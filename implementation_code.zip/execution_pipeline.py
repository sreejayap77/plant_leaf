import os
import glob
import random
import numpy as np
from scipy import stats
from tqdm import tqdm  # Added tqdm for tracking progress
import csv  # Added for saving and loading results
import pandas as pd  # Added for saving convergence safely

# Import custom IoT modules
from iot_simulation import IoTSimulation
from dataset_connector import DatasetConnector

# Import the dynamic SEWWSA Optimizer
from SEwWSA import SEwWSAOptimizer

# Import separated deep learning models
from proposed_method.CNN_1D import DiseaseDetector1DCNN, TomatoLeafDataset, train_and_save_1dcnn
from proposed_method.polynet import train_and_evaluate_hybrid
from proposed_method.merge_func import merge_layer


def generate_statistical_reports(fitness_history_sewwsa: list, baseline_fitness: list):
    t_stat, p_value = stats.ttest_rel(baseline_fitness, fitness_history_sewwsa)
    return t_stat, p_value


def execute_func(
        dataset_directory: str,
        preprocessed_directory: str,
        train_percent: float = 0.8,
        num_nodes: int = 50,
        num_rounds: int = 1000
):
    num_epochs = 100
    optimization_iterations = num_rounds

    # ==========================================
    # IoT Topology & Optimization
    # ==========================================
    iot_env = IoTSimulation(num_nodes=num_nodes, grid_size=100.0, n_clusters=5)
    iot_env.deploy_nodes()
    iot_env.form_clusters()
    iot_env.update_network_trust_and_qos()

    dataset_connector = DatasetConnector(dataset_path=dataset_directory)
    sensor_reading = dataset_connector.get_random_sensor_reading()
    source_node = random.choice([n for n in iot_env.nodes if not n.is_cluster_head])
    payload_bytes = sensor_reading['file_size_bytes']

    def real_routing_objective(position_vector):
        num_chs = len(iot_env.cluster_heads)
        if num_chs == 0:
            return 1.0

        total_ec = 0.0
        total_dist = 0.0
        total_delay = 0.0
        path_trust = 0.0
        continuous_penalty = 0.0

        current_coords = source_node.get_coordinates()
        payload_bits = payload_bytes * 8
        num_hops = len(position_vector) // 2

        for i in range(num_hops):
            ideal_x = position_vector[i * 2] * iot_env.grid_size
            ideal_y = position_vector[i * 2 + 1] * iot_env.grid_size
            ideal_coords = np.array([ideal_x, ideal_y])

            distances_to_chs = [np.linalg.norm(ideal_coords - ch.get_coordinates()) for ch in iot_env.cluster_heads]
            next_hop_ch = iot_env.cluster_heads[np.argmin(distances_to_chs)]

            target_coords = next_hop_ch.get_coordinates()
            continuous_penalty += np.linalg.norm(ideal_coords - target_coords) * 0.0001
            dist = np.linalg.norm(current_coords - target_coords)

            if dist < iot_env.optimizer.config.d0:
                ec = (iot_env.optimizer.config.E_elec * payload_bits) + (
                        iot_env.optimizer.config.E_fs * payload_bits * (dist ** 2))
            else:
                ec = (iot_env.optimizer.config.E_elec * payload_bits) + (
                        iot_env.optimizer.config.E_mp * payload_bits * (dist ** 4))

            delay = iot_env.optimizer.config.processing_delay + (dist / iot_env.optimizer.config.prop_speed)

            total_dist += dist
            total_ec += ec
            total_delay += delay
            path_trust += next_hop_ch.trust
            current_coords = target_coords

        bs_coords = iot_env.base_station.get_coordinates()
        dist = np.linalg.norm(current_coords - bs_coords)

        if dist < iot_env.optimizer.config.d0:
            ec = (iot_env.optimizer.config.E_elec * payload_bits) + (
                    iot_env.optimizer.config.E_fs * payload_bits * (dist ** 2))
        else:
            ec = (iot_env.optimizer.config.E_elec * payload_bits) + (
                    iot_env.optimizer.config.E_mp * payload_bits * (dist ** 4))

        delay = iot_env.optimizer.config.processing_delay + (dist / iot_env.optimizer.config.prop_speed)

        total_dist += dist
        total_ec += ec
        total_delay += delay

        total_hops = num_hops + 1
        avg_ec = total_ec / total_hops
        avg_dist = total_dist / total_hops
        avg_delay = total_delay / total_hops
        avg_trust = path_trust / num_hops
        qos = iot_env.qos

        base_fitness = iot_env.optimizer.calculate_fitness(avg_ec, avg_dist, avg_delay, avg_trust, qos)
        return base_fitness + continuous_penalty

    def extract_iot_metrics(position_vector):
        if position_vector is None or len(iot_env.cluster_heads) == 0:
            return 0.0, 0.0

        total_ec = 0.0
        total_delay = 0.0
        current_coords = source_node.get_coordinates()
        payload_bits = payload_bytes * 8
        num_hops = len(position_vector) // 2

        for i in range(num_hops):
            ideal_x = position_vector[i * 2] * iot_env.grid_size
            ideal_y = position_vector[i * 2 + 1] * iot_env.grid_size
            ideal_coords = np.array([ideal_x, ideal_y])
            distances_to_chs = [np.linalg.norm(ideal_coords - ch.get_coordinates()) for ch in iot_env.cluster_heads]
            next_hop_ch = iot_env.cluster_heads[np.argmin(distances_to_chs)]
            target_coords = next_hop_ch.get_coordinates()
            dist = np.linalg.norm(current_coords - target_coords)

            if dist < iot_env.optimizer.config.d0:
                total_ec += (iot_env.optimizer.config.E_elec * payload_bits) + (
                        iot_env.optimizer.config.E_fs * payload_bits * (dist ** 2))
            else:
                total_ec += (iot_env.optimizer.config.E_elec * payload_bits) + (
                        iot_env.optimizer.config.E_mp * payload_bits * (dist ** 4))

            total_delay += iot_env.optimizer.config.processing_delay + (dist / iot_env.optimizer.config.prop_speed)
            current_coords = target_coords

        bs_coords = iot_env.base_station.get_coordinates()
        dist = np.linalg.norm(current_coords - bs_coords)

        if dist < iot_env.optimizer.config.d0:
            total_ec += (iot_env.optimizer.config.E_elec * payload_bits) + (
                    iot_env.optimizer.config.E_fs * payload_bits * (dist ** 2))
        else:
            total_ec += (iot_env.optimizer.config.E_elec * payload_bits) + (
                    iot_env.optimizer.config.E_mp * payload_bits * (dist ** 4))

        total_delay += iot_env.optimizer.config.processing_delay + (dist / iot_env.optimizer.config.prop_speed)

        return total_ec, total_delay

    sewwsa_opt = SEwWSAOptimizer(num_particles=20, dim=20, max_iter=optimization_iterations, lb=-1.0, ub=1.0)
    sewwsa_opt._initialize_population()

    fitness_history = []
    baseline_history = []
    energy_history = []
    delay_history = []
    best_pos = None

    # Added tqdm to track the optimization progress
    for t in tqdm(range(1, optimization_iterations + 1), desc="IoT Routing Optimization Iterations"):
        best_pos, current_best_fitness = sewwsa_opt.optimize(real_routing_objective)
        fitness_history.append(current_best_fitness)
        random_path_vector = np.random.rand(20)
        baseline_history.append(real_routing_objective(random_path_vector))

        # Track energy and delay metrics per round
        curr_energy, curr_delay = extract_iot_metrics(best_pos)
        energy_history.append(curr_energy)
        delay_history.append(curr_delay)

    # ==========================================
    # CSV Saving: Save Energy and Delay per round
    # ==========================================
    hist_filename = "history.csv"
    col_name_energy = f"Rounds_{optimization_iterations}_Energy"
    col_name_delay = f"Rounds_{optimization_iterations}_Delay"

    if os.path.exists(hist_filename):
        df_hist = pd.read_csv(hist_filename)
    else:
        df_hist = pd.DataFrame()

    # Check if this configuration already exists to avoid overwriting
    if col_name_energy not in df_hist.columns:
        # Manage the 'Rounds' column
        if 'Rounds' not in df_hist.columns:
            df_hist['Rounds'] = range(1, len(energy_history) + 1)
        elif len(energy_history) > len(df_hist):
            df_hist = df_hist.reindex(range(len(energy_history)))
            df_hist['Rounds'] = range(1, len(energy_history) + 1)

        # Pad with NaNs in case columns are of unequal length
        padded_energy = energy_history + [np.nan] * (len(df_hist) - len(energy_history))
        padded_delay = delay_history + [np.nan] * (len(df_hist) - len(delay_history))

        df_hist[col_name_energy] = padded_energy
        df_hist[col_name_delay] = padded_delay

        df_hist.to_csv(hist_filename, index=False)


    # plot_optimization_loss(fitness_history, baseline_history, optimization_iterations)
    generate_statistical_reports(fitness_history, baseline_history)

    final_energy_j, final_delay_s = extract_iot_metrics(best_pos)

    # ==========================================
    # 1D CNN Training & Logit Extraction
    # ==========================================
    image_paths = glob.glob(os.path.join(dataset_directory, "*", "*.*"))
    if not image_paths:
        return None

    cnn_dataset = TomatoLeafDataset(image_paths)
    cnn_model = DiseaseDetector1DCNN(num_classes=10)

    X1 = train_and_save_1dcnn(
        model=cnn_model,
        dataset=cnn_dataset,
        train_percent=train_percent,
        num_epochs=num_epochs,
        batch_size=32
    )

    # ==========================================
    # PolyNet Hybrid Fusion
    # ==========================================

    X2 = train_and_evaluate_hybrid(
        X1,
        train_percent=train_percent,
        num_epochs=num_epochs,
        batch_size=4,
        raw_data_dir=dataset_directory
    )

    # ==========================================
    # STAGE 4: Final Merge Layer
    # ==========================================

    acc_list, sen_list, spe_list, pre_list, f1_list, bl_acc_list, energy_list, delay_list = [], [], [], [], [], [], [], []

    merge_layer(
        dataset_dir=preprocessed_directory,
        polynet_preds_data=X2,
        Accuracy=acc_list,
        Sensitivity=sen_list,
        Specificity=spe_list,
        Precision=pre_list,
        F1_score=f1_list
    )

    balanced_accuracy = (sen_list[0] + spe_list[0]) / 2.0

    bl_acc_list.append(balanced_accuracy)
    energy_list.append(final_energy_j)
    delay_list.append(final_delay_s)

    # ==========================================
    # CSV Loading/Saving Logic (Multi-table format)
    # ==========================================
    csv_filename = "results.csv"
    scaled_train_percent = round(train_percent * 100, 2)

    dl_headers = ["Train_Perc", "Accuracy", "Sensitivity", "Specificity", "Precision", "F1_Score", "Balanced_Accuracy"]
    iot_headers = ["Rounds", "Energy_J", "Delay_S"]

    dl_data = []
    iot_data = []

    # Parse existing file to separate blocks
    if os.path.exists(csv_filename):
        with open(csv_filename, mode='r', newline='') as file:
            reader = csv.reader(file)
            current_block = None
            for row in reader:
                if not row or not any(row):  # Skip empty lines
                    continue
                if row[0] == "Train_Perc":
                    current_block = "DL"
                    continue
                elif row[0] == "Rounds":
                    current_block = "IOT"
                    continue

                # Store rows dynamically based on the current block
                if current_block == "DL":
                    dl_data.append({dl_headers[i]: float(row[i]) for i in range(len(dl_headers))})
                elif current_block == "IOT":
                    iot_data.append({iot_headers[i]: float(row[i]) for i in range(len(iot_headers))})

    # Update or preserve DL metrics
    found_dl = False
    ret_dl = None
    for row in dl_data:
        if abs(row["Train_Perc"] - scaled_train_percent) < 1e-5:
            found_dl = True
            ret_dl = ([row["Accuracy"]], [row["Sensitivity"]], [row["Specificity"]],
                      [row["Precision"]], [row["F1_Score"]], row["Balanced_Accuracy"])
            break

    if not found_dl:
        new_dl = {
            "Train_Perc": scaled_train_percent,
            "Accuracy": acc_list[0] if acc_list else 0.0,
            "Sensitivity": sen_list[0] if sen_list else 0.0,
            "Specificity": spe_list[0] if spe_list else 0.0,
            "Precision": pre_list[0] if pre_list else 0.0,
            "F1_Score": f1_list[0] if f1_list else 0.0,
            "Balanced_Accuracy": balanced_accuracy
        }
        dl_data.append(new_dl)
        ret_dl = (acc_list, sen_list, spe_list, pre_list, f1_list, balanced_accuracy)

    # Update or preserve IOT metrics
    found_iot = False
    ret_iot = None
    for row in iot_data:
        if abs(row["Rounds"] - optimization_iterations) < 1e-5:
            found_iot = True
            ret_iot = (row["Energy_J"], row["Delay_S"])
            break

    if not found_iot:
        new_iot = {
            "Rounds": optimization_iterations,
            "Energy_J": final_energy_j,
            "Delay_S": final_delay_s
        }
        iot_data.append(new_iot)
        ret_iot = (final_energy_j, final_delay_s)

    # Sort blocks for clean presentation
    dl_data = sorted(dl_data, key=lambda x: x["Train_Perc"])
    iot_data = sorted(iot_data, key=lambda x: x["Rounds"])

    # Overwrite the CSV with the dual-table format
    with open(csv_filename, mode='w', newline='') as file:
        writer = csv.writer(file)

        # Write DL table
        writer.writerow(dl_headers)
        for row in dl_data:
            writer.writerow([row[h] for h in dl_headers])

        # Add visual separation
        writer.writerow([])
        writer.writerow([])
        writer.writerow([])

        # Write IOT table
        writer.writerow(iot_headers)
        for row in iot_data:
            writer.writerow([row[h] for h in iot_headers])

    # Unpack stored values for return
    acc_out, sen_out, spe_out, pre_out, f1_out, bal_acc_out = ret_dl
    energy_out, delay_out = ret_iot

    return acc_out, sen_out, spe_out, pre_out, f1_out, bal_acc_out, energy_out, delay_out