import numpy as np
from sklearn.cluster import KMeans
from dataclasses import dataclass, field
from typing import Tuple, List, Optional

np.random.seed(42)


@dataclass
class HardwareConfig:
    """Standard Radio Model parameters and metric normalizers."""
    E_elec: float = 50e-9
    E_fs: float = 10e-12
    E_mp: float = 0.0013e-12

    d0: float = field(init=False)

    prop_speed: float = 2e8
    processing_delay: float = 0.005

    max_energy: float = 0.5
    max_distance: float = 141.4
    max_delay: float = 0.05

    neighbor_radius: float = 100.0  # Radius to identify neighbor nodes
    f_norm: float = 100.0  # Normalization factor for LLT

    def __post_init__(self):
        self.d0 = np.sqrt(self.E_fs / self.E_mp)


class SensorNode:
    """Physical node tracking coordinates, energy, and localized trust metrics."""

    def __init__(self, node_id: int, x: float, y: float, initial_energy: float = 0.5):
        self.node_id = node_id
        self.coordinates = np.array([x, y])
        self.is_cluster_head = False
        self.cluster_id = None

        self.energy = initial_energy
        self.config = HardwareConfig()

        # Routing metrics
        self.last_delay = 0.0
        self.direct_trust = 1.0
        self.trust = 1.0
        self.neighbors: List[int] = []

    def get_coordinates(self) -> np.ndarray:
        return self.coordinates

    def simulate_transmission(self, target_coords: np.ndarray, payload_bytes: int) -> Tuple[float, float, float]:
        """Calculates transmission distance, energy consumption, and delay."""
        payload_bits = payload_bytes * 8
        distance = np.linalg.norm(self.coordinates - target_coords)

        if distance < self.config.d0:
            ec = (self.config.E_elec * payload_bits) + (self.config.E_fs * payload_bits * (distance ** 2))
        else:
            ec = (self.config.E_elec * payload_bits) + (self.config.E_mp * payload_bits * (distance ** 4))

        delay = self.config.processing_delay + (distance / self.config.prop_speed)

        # Update node state for trust calculation
        self.energy = max(self.energy - ec, 0.0)
        self.last_delay = delay

        return distance, ec, delay


class BaseStation:
    """Central sink node for collecting data."""

    def __init__(self, x: float, y: float):
        self.coordinates = np.array([x, y])

    def get_coordinates(self) -> np.ndarray:
        return self.coordinates


class RoutingOptimizer:
    """Normalizes metrics and calculates the multi-objective fitness."""

    def __init__(self, config: Optional[HardwareConfig] = None):
        self.config = config if config is not None else HardwareConfig()

    def apply_nf(self, value: float, max_val: float) -> float:
        return min(max(value / max_val, 0.0), 1.0)

    def calculate_fitness(self, ec: float, distance: float, delay: float, trust: float, qos: float) -> float:
        """Expanded Fitness: F = ((1-E) + (1-D) + T + QoS + (1-d)) / 5."""
        norm_ec = self.apply_nf(ec, self.config.max_energy)
        norm_d = self.apply_nf(distance, self.config.max_distance)
        norm_delay = self.apply_nf(delay, self.config.max_delay)

        fitness = ((1.0 - norm_ec) + (1.0 - norm_d) + trust + qos + (1.0 - norm_delay)) / 5.0
        return fitness


class IoTSimulation:
    """Manages topology, clustering, and advanced network metrics."""

    # --> Specify num_nodes and num_rounds here during initialization
    def __init__(self, num_nodes: int = 50, num_rounds: int = 500, grid_size: float = 100.0, n_clusters: int = 5):
        self.num_nodes = num_nodes
        self.num_rounds = num_rounds
        self.grid_size = grid_size
        self.n_clusters = n_clusters
        self.nodes: List[SensorNode] = []
        self.cluster_heads: List[SensorNode] = []
        self.base_station = BaseStation(grid_size / 2, grid_size / 2)
        self.optimizer = RoutingOptimizer()
        self.qos = 1.0

    def deploy_nodes(self):
        """Scatters nodes and maps neighbor relationships based on distance."""
        coords = np.random.rand(self.num_nodes, 2) * self.grid_size
        for i in range(self.num_nodes):
            self.nodes.append(SensorNode(node_id=i, x=coords[i, 0], y=coords[i, 1]))

        # Identify neighbors within neighbor_radius
        for i, node in enumerate(self.nodes):
            for j, other_node in enumerate(self.nodes):
                if i != j:
                    dist = np.linalg.norm(node.get_coordinates() - other_node.get_coordinates())
                    if dist < node.config.neighbor_radius:
                        node.neighbors.append(j)

    def form_clusters(self):
        coords = np.array([node.get_coordinates() for node in self.nodes])
        kmeans = KMeans(n_clusters=self.n_clusters, random_state=42)
        labels = kmeans.fit_predict(coords)

        for i, node in enumerate(self.nodes):
            node.cluster_id = labels[i]

        for cluster_idx in range(self.n_clusters):
            cluster_nodes = [n for n in self.nodes if n.cluster_id == cluster_idx]
            cluster_center = kmeans.cluster_centers_[cluster_idx]

            closest_node = min(cluster_nodes, key=lambda n: np.linalg.norm(n.get_coordinates() - cluster_center))
            closest_node.is_cluster_head = True
            self.cluster_heads.append(closest_node)

    def update_network_trust_and_qos(self):
        """Calculates Direct Trust, Indirect Trust, and network-wide QoS."""
        # 1. Direct Trust (DT)
        for node in self.nodes:
            node.direct_trust = max(1.0 - node.last_delay, 0.0)

        # 2. Indirect Trust (InDT) & final node trust
        for node in self.nodes:
            if len(node.neighbors) > 0:
                indt = sum(self.nodes[n].direct_trust for n in node.neighbors) / len(node.neighbors)
            else:
                indt = 0.0
            node.trust = (node.direct_trust + indt) / 2.0

        # 3. Quality of Service (QoS)
        self.qos = np.mean([node.trust for node in self.nodes])

    def calculate_link_lifetime(self, source: SensorNode, target: SensorNode) -> float:
        """LLT based on node distances and energy minimums."""
        distance = np.linalg.norm(source.get_coordinates() - target.get_coordinates())
        lt_xi = distance / source.config.f_norm

        # LLT is bounded by the minimum remaining energy of the communicating nodes
        llt = min(lt_xi, source.energy, target.energy)
        return llt