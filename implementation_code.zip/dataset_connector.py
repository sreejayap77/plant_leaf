import os
import random
from pathlib import Path


class DatasetConnector:
    """Links the physical IoT simulation to the actual image dataset[cite: 2]."""

    def __init__(self, dataset_path: str):
        self.dataset_path = Path(dataset_path)
        self.image_paths = self._load_image_paths()

    def _load_image_paths(self) -> list:
        """Scans the directory structure for all valid leaf images[cite: 2]."""
        valid_extensions = {'.jpg', '.jpeg', '.png'}
        images = []

        for root, _, files in os.walk(self.dataset_path):
            for file in files:
                if Path(file).suffix.lower() in valid_extensions:
                    images.append(os.path.join(root, file))
        return images

    def get_random_sensor_reading(self) -> dict:
        """Randomly selects an image and calculates its exact file size for the IoT simulation."""
        if not self.image_paths:
            raise FileNotFoundError(f"No images found in {self.dataset_path}. Please check the path.")

        selected_image = random.choice(self.image_paths)

        # Fetch the actual byte size of the image on disk to use as the transmission payload
        file_size_bytes = os.path.getsize(selected_image)

        # Extract the disease class name from the folder structure for logging
        class_name = os.path.basename(os.path.dirname(selected_image))

        return {
            "file_path": selected_image,
            "class_label": class_name,
            "file_size_bytes": file_size_bytes
        }